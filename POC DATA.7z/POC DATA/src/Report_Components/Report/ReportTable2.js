import React, { Component } from 'react';
import ReactTable from 'react-table'
import 'react-table/react-table.css'
import axios from 'axios'
import './Report.css'

class ReportTable2 extends Component {
  constructor() {
    super();
    this.state={
        data : [],
        columns : [
          {
            Header: 'CORD DATE',
            accessor: 'DATE'
          }, {
            Header: 'MERCHANT NUMBER',
            accessor: 'NUMBER',
            width:150,
            Cell: props => <span className='number'>{props.value}</span>
          },
          {
            Header: 'MERCHANT NAME',
            accessor: 'NAME',
            width:150,
          },
          {
            Header: 'MERCHANT CITY',
            accessor: 'CITY',
            width : 200
          },
          {
            Header: 'TRANS. AMOUNT CHARGE',
            accessor: 'AMOUNT',
            Cell: props => <span className='number'>{props.value}</span>
          },
          {
            Header: 'TRANS. CURRENCY',
            accessor: 'TCURRENCY',
            Cell: props => <span className='number'>{props.value}</span>
          },
          {
            Header: 'CHARGE TYPE',
            accessor: 'TYPE'
          },
          {
            Header: 'CHARGEBACK REASON',
            accessor: 'REASON',
            width : 350
          },
          {
            Header: 'CARD BRAND',
            accessor: 'BRAND'
          }
        ]
    }
 }

   componentWillMount(){
     let that = this;
     axios.get('http://localhost:8080/merchantStatement/chargeback?merchantNumber=5644588')
       .then(function (response) {
           let arr = response.data.chargeBackResponse;
           let rows = [];
           arr.map((i)=>{
           rows.push({
             DATE: i.recordDate,
             NUMBER: i.merchantNumber,
             NAME : i.merchantName,
             CITY: i.merchantCity,
             AMOUNT : i.tranAmountChg,
             CURRENCY : i.acctCurrency,
             TCURRENCY : i.tranCurrency,
             TYPE : i.chargeType,
             REASON : i.chargeBackReason,
             BRAND : i.cardBrand
           });
         });
         that.setState((prevState,props)=>{
          return {data:rows};
        });
       })
       .catch(function (error) {
         console.log(error);
       });
   }

 render(){


   return(
     <div>
     <div className="page-header table_info">
         <strong >REPORT 1</strong>
         <p >Your Chargeback amount details</p>
     </div>
     <ReactTable
        data={this.state.data}
        columns={this.state.columns}
        className="-striped -highlight"
        minRows ={10}
        noDataText="Oh Noes!"
        style={{
            height: "500px" // This will force the table body to overflow and scroll, since there is not enough room
          }}
    />
    </div>
   )
 }
}

export default ReportTable2;
