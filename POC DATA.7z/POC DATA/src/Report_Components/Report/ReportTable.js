import React, { Component } from 'react';
import ReactDataGrid from 'react-data-grid'
import axios from 'axios'
import './Report.css'


class ReportTable extends Component {
  constructor() {
    super();

    this._columns = [
      {
        key: 'DATE',
        name: 'CORD DATE',
        width: 90
      },
      {
        key: 'NUMBER',
        name: 'MERCHANT NUMBER',
        width: 80,
        sortable: true
      },
      {
        key: 'NAME',
        name: 'MERCHANT NAME',
        width: 100,
        sortable: true
      },
      {
        key: 'CITY',
        name: 'MERCHANT CITY',
        width: 100,
        sortable: true
      },
      {
        key: 'AMOUNT',
        name: 'TRANS. AMOUNT CHARGE',
        width: 50
      },
      {
        key: 'CURRENCY',
        name: 'ACCOUNT CURRENCY',
        width: 50
      },
      {
        key: 'TCURRENCY',
        name: 'TRANS. CURRENCY',
        width: 50
      },
      {
        key: 'TYPE',
        name: 'CHARGE TYPE',
        width: 100,
        sortable: true
      },
      {
        key: 'REASON',
        name: 'CHARGEBACK REASON',
        width: 300
      },
      {
        key: 'BRAND',
        name: 'CARD BRAND',
        width: 100,
        sortable: true
      }

    ];

    this.state = { originalRows : [] ,
                    rows : [] };
  }

  componentWillMount(){
    let that = this;
    axios.get('http://localhost:8080/merchantStatement/chargeback?merchantNumber=5644588')
      .then(function (response) {
          let arr = response.data.chargeBackResponse;
          let originalRows = that.createRows(arr);
          let rows = originalRows.slice(0);
          that.setState((prevState,props)=>{
           return {originalRows};
         });
         that.setState((prevState,props)=>{
          return {rows};
        });
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  createRows(data) {
    let rows = [];

    data.map((i)=>{
      rows.push({
        DATE: i.recordDate,
        NUMBER: i.merchantNumber,
        NAME : i.merchantName,
        CITY: i.merchantCity,
        AMOUNT : i.tranAmountChg,
        CURRENCY : i.acctCurrency,
        TCURRENCY : i.tranCurrency,
        TYPE : i.chargeType,
        REASON : i.chargeBackReason,
        BRAND : i.cardBrand
      });
    });
    console.log(rows)
    return rows;
  };

  handleGridSort = (sortColumn, sortDirection) => {
    const comparer = (a, b) => {
      if (sortDirection === 'ASC') {
        return (a[sortColumn] > b[sortColumn]) ? 1 : -1;
      } else if (sortDirection === 'DESC') {
        return (a[sortColumn] < b[sortColumn]) ? 1 : -1;
      }
    };

    const rows = sortDirection === 'NONE' ? this.state.originalRows.slice(0) : this.state.rows.sort(comparer);

    this.setState({ rows });
  };

  rowGetter = (i) => {
    return this.state.rows[i];
  };


  render() {

    return (
      <div >
            <div className="page-header table_info">
                <strong >REPORT 1</strong>
                <p >Your Chargeback amount details</p>
            </div>
            <div >
            <ReactDataGrid
                onGridSort={this.handleGridSort}
                columns={this._columns}
                rowGetter={this.rowGetter}
                rowsCount={this.state.rows.length}
                minHeight={500} />);
            </div>
      </div>
    );
  }
}

export default ReportTable;
