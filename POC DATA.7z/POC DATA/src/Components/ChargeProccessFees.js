import React, { Component } from 'react';
import { render } from 'react-dom';
import '../Style/navbar.css'


let ChargeProccessFees =(props) => {


    return (
      <div className="row">
          <div className="col col-md-6 ">
              <div className="mer_charge">
                  <div className="details_title">Your Chargebacks  <span className="currency"> March 2018</span></div>
                  <div>
                      <span className="glyphicon glyphicon-triangle-bottom"></span>
                      <strong className="amount">1,782.00</strong>
                      <span className="currency"> GBP</span>
                  </div>
                  <div>Decrease <span className="increase_rate">4%</span> <span className="currency">from February 2018</span></div>
              </div>
          </div>
          <div className="col col-md-6 ">
              <div className="mer_charge">
                  <div className="details_title">Your Processsing Fees <span className="currency"> March 2018</span></div>
                  <div>
                      <strong className="amount">2,830.00</strong>
                      <span className="currency"> GBP</span>
                  </div>
              </div>
          </div>
      </div>
    );
  
}

export default ChargeProccessFees;
