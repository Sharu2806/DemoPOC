import React, { Component } from 'react';
import { render } from 'react-dom';
import '../Style/navbar.css'


class NetSaleInviceDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: 'React'
    };
  }

  render() {
    return (
      <div className="row">
          <div className="col col-md-6 ">
              <div className="mer_total">
                  <div className="details_title">Your Sales <span className="currency"> March 2018</span></div>
                  <div>
                      <span className="glyphicon glyphicon-triangle-top"></span>
                      <strong className="amount">46,786.00</strong>
                      <span className="currency"> GBP</span>
                  </div>
                  <div>Increase <span className="increase_rate">23%</span> <span className="currency">from February 2018</span></div>
              </div>
          </div>
          <div className="col col-md-6 ">
              <div className="mer_total">
                  <div className="details_title">Invoice <span className="currency"> February 2018</span></div>
                  <div>
                      <strong className="amount">46,786.00</strong>
                      <span className="currency"> GBP</span>
                  </div>
              </div>
          </div>
      </div>
    );
  }
}

export default NetSaleInviceDetails;
