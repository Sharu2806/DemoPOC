import React, { Component } from 'react';
import { render } from 'react-dom';
import '../Style/navbar.css'
import axios from 'axios';


class MerchantDetails extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    if(this.props.merchantInfo !== undefined){
    return (
      <div className="col col-md-6 marchant_info">
        <div className="row mdetails">
          <div className="col col-md-3">
              <img src="images/merchant_logo.png" alt="logo"></img>
          </div>
          <div className="col col-md-8">
              <h4><strong>{this.props.merchantInfo.name}</strong></h4>
              <h5>{this.props.merchantInfo.number}</h5>
              <h5>{this.props.merchantInfo.city}</h5>
          </div>
        </div>
        <div className="pull-right mem_type">PLATINUM MEMBER</div>
      </div>
    );
  }else{
    return(
           <div>Please Wait....</div>
    );
  }
}
}

export default MerchantDetails;
