import React, { Component } from 'react';
import { render } from 'react-dom';
import axios from 'axios';
import '../Style/navbar.css'
import '../style.css';

class PieCharts extends Component {
  constructor(props) {
    super(props);
    this.state ={
      pie : []
    }
    this.drawChart = this.drawChart.bind(this);
  }

  componentWillReceiveProps(newProps){
    if(newProps.pieChartDetails !== undefined){
      this.setState({
          pie : newProps.pieChartDetails
      });
    }

  }

  componentDidMount(){
    window.google.charts.load('current', {'packages':['corechart']});
    window.google.charts.setOnLoadCallback(() => this.drawChart());
  }

  drawChart() {

    console.log(this.state.pie);
    if(this.props.pieChartDetails.length !== 0){
        var data = [];
        for (var i = 0; i < this.props.pieChartDetails.length; i++) {
                  data[i] = [this.props.pieChartDetails[i][0], this.props.pieChartDetails[i][1]];
            }
        var chartData = window.google.visualization.arrayToDataTable(data);
        var options = {
          backgroundColor: {
            fill: '#fff'
          },
          title: 'Your Chargeback Summary',
          colors: ['#144C73', '#2C82BE', '#53A8E2', '#76DDFB'],
          pieHole: 0.3,
          chartArea : {top:30,width:'100%',height:'75%'},
          legend : {position:'bottom',textStyle: {color: '#4A5265', fontSize: 15}},
          height: 300
        };
        var chart = new window.google.visualization.PieChart(this.textInput);

        chart.draw(chartData, options);
    }

  }
   render() {
     window.google.charts.load('current', {'packages':['corechart']});
     window.google.charts.setOnLoadCallback(() => this.drawChart());
    return (
          <div ref={(input) => { this.textInput = input; }}></div>
    );
    }

}

export default PieCharts;
