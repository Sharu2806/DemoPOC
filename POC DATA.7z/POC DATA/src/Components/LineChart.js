import React, { Component } from 'react';
import { render } from 'react-dom';
import axios from 'axios';
import '../Style/navbar.css'
import '../style.css';

//google.charts.load('current', {'packages':['corechart']});
class LineChart extends Component {
  constructor(props) {
    super(props);
    this.state ={
      dataFromProps : [],
      Data  :[]
    }
    this.drawChart = this.drawChart.bind(this);
  }

  componentWillReceiveProps(newprops){
      let details = newprops.lineChartDetails;
      if(details.length !== 0){
      let arr = [['Month',details[0].merchantName,details[0].competitor_merchantName]];

      details.forEach((i)=>{
          let a = [];
          a.push(i.month)
          a.push(i.netSaleAmount)
          a.push(i.competitor_netsaleAmount)
          arr.push(a);
      })

      this.setState((prevState,props)=>{
         return {Data:arr};
      });
    }

  }

  componentDidMount(){
    window.google.charts.load('current', {'packages':['corechart']});
    window.google.charts.setOnLoadCallback(() => this.drawChart());
  }

  drawChart() {
        var data = [];
        for (var i = 0; i < this.props.lineChartDetails.length; i++) {
                  data[i] = [this.props.lineChartDetails[i][0],this.props.lineChartDetails[i][1], this.props.lineChartDetails[i][2]];
            }

        var chartData = window.google.visualization.arrayToDataTable(data);
        var options = {
             title: 'See how you are perfomring compared to similar businesses',
             curveType: 'none',
             legend: { position: 'bottom' },
   	         backgroundColor: {
               fill: '#fff',
               fillOpacity: 0.8
             },
             height : '500px',
             pointShape : 'circle',
             pointSize: 10,
             height: 300,
             colors: ['#144C73', '#53A8E2', '#76DDFB']

           };

        var chart = new window.google.visualization.LineChart(this.lineChart);
        chart.draw(chartData, options);
  }
   render() {
     window.google.charts.load('current', {'packages':['corechart']});
     window.google.charts.setOnLoadCallback(() => this.drawChart());
    return (
          <div ref={(input) => { this.lineChart = input; }}></div>
    );
    }

}

export default LineChart;
