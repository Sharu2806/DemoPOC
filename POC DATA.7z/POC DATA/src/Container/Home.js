import React, { Component } from 'react';
import axios from 'axios';
import Header from '../Components/Header';
import Sidebar from '../Components/Sidebar';
import HeadingInfo from '../Components/HeadingInfo'
import Details from '../Components/Details'
import '../Style/navbar.css'


class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
      mInfo : {},
      pieChartData : [],
      lineChartData : []


    };
  }
  componentWillMount(){
      this.fetchChargeBackData();
      this.fetchPerformanceCompareData();
      this.fetchNetSaleDetailsByLocation();
  }

  fetchChargeBackData(){
    let that = this;
    axios.get('http://localhost:8080/merchantStatement/chargeback?merchantNumber=5644588')
      .then(function (response) {
          let obj = response.data.chargeBackResponse;
          let info ={name:'', city:'',number : ''};
          let data = [['Card Brand', 'ChargeBack']];
          info.name = obj[0].merchantName;
          info.number = obj[0].merchantNumber;
          info.city = obj[0].merchantCity;

        that.setState((prevState,props)=>{
            return {mInfo : info}
        });


        obj.forEach((i)=>{
          let details =[];
           details[0] = i.cardBrand;
           details[1] = i.tranAmountChg
           data.push(details);
        })
        that.setState((prevState,props)=>{
         return {pieChartData : data};
      });
      }).catch(function (error) {
        console.log(error);
      });
  }

  fetchPerformanceCompareData(){
    let that = this;
    axios.get('http://localhost:8080/merchantTradeNetSale/comparativenetsales?merchantNumber=5644588')
      .then(function (response) {
          let obj = response.data.merchantCompetitorNetSale;
          if(obj.length !== 0){
          let arr = [['Month',obj[0].merchantName,obj[0].competitor_merchantName]];

          obj.forEach((i)=>{
              let a = [];
              a.push(i.month)
              a.push(i.netSaleAmount)
              a.push(i.competitor_netsaleAmount)
              arr.push(a);
          })
          that.setState((prevState,props)=>{
             return {lineChartData:arr};
          });
        }
      }).catch(function (error) {
        console.log(error);
      });
  }

  fetchNetSaleDetailsByLocation(){
    let that = this;
    axios.get('http://localhost:8080/merchantTradeNetSale/tradenetsale?merchantNumber=5644588')
      .then(function (response) {
        let obj = response.data.merchantTradeNetSale;
        let rowOne =['month'];
        let data = [];
        obj.map((i)=>rowOne.push(i.merchantCity) );
        data.push(rowOne);
        obj.map((i)=>{
          data.push(i.month,i.netSaleAmount)
        })
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  render() {

    return (
      <div>
          <Header />
          <div id="wrapper">
            <Sidebar />
            <div id="main-wrapper" className="col-md-10 pull-right">
              <HeadingInfo/>
              <div id="main">
                  <Details info={this.state.mInfo} dataToPass={this.state.pieChartData} dataForLineChart={this.state.lineChartData}/>
              </div>
            </div>
          </div>
        </div>
    );
  }
}

export default Home;
