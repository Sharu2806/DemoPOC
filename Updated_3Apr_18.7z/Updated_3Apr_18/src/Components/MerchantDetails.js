import React, { Component } from 'react';
import { render } from 'react-dom';
import '../Style/navbar.css'
import axios from 'axios';


class MerchantDetails extends Component {
  constructor() {
    super();
    this.state ={
      name : "",
      number : "",
      city : ""

    }


  }

  componentWillMount(){
    let that = this;
    axios.get('http://localhost:8080/merchantStatement/chargeback?merchantNumber=5644588')
      .then(function (response) {
        that.setState({
          name : response.data.chargeBackResponse[0].merchantName,
          number : response.data.chargeBackResponse[0].merchantNumber,
          city : response.data.chargeBackResponse[0].merchantCity
        })
      })
      .catch(function (error) {
        console.log(error);
    });
  }

  render() {
    return (
      <div className="col col-md-6 marchant_info">
        <div className="row mdetails">
          <div className="col col-md-3">
              <img src="images/merchant_logo.png" alt="logo"></img>
          </div>
          <div className="col col-md-8">
              <h4><strong>{this.state.name}</strong></h4>
              <h5>{this.state.number}</h5>
              <h5>{this.state.city}</h5>
          </div>
        </div>
        <div className="pull-right mem_type">PLATINUM MEMBER</div>
      </div>
    );
  }
}

export default MerchantDetails;
