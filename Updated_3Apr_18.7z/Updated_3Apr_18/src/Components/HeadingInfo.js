import React, { Component } from 'react';
import Details from './Details';
import '../Style/navbar.css'
import '../style.css'

let HeadingInfo = () => {
 return(
     <div className="page-header header_info">
         <strong className="lead">Welcome</strong>
         <p>Detailed information and analysis of your transactions</p>
     </div>
 )
};

export default HeadingInfo;
