import React, { Component } from 'react';
import ReportTable2 from './ReportTable2'
import '../../Style/navbar.css'


class ReportDetails extends Component {
  constructor() {
    super();


  }
  render() {
    return (
      <div className="panel panel-default">
        <div className="panel-body">
            <ReportTable2 />
        </div>
      </div>

    );
  }
}

export default ReportDetails;
