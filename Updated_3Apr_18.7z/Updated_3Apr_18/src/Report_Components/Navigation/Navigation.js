import React, { Component } from 'react';
import './Navigation.css'


let Navigation = () =>{
    return (
      <nav className="report_nav navbar navbar-default">
          <ul className="nav navbar-nav">
            <li className="active"><a href="#">Chargeback</a></li>
            <li><a href="#">Processing Fess</a></li>
            <li><a href="#">Net Sales</a></li>
          </ul>
      </nav>
    );
}


export default Navigation;
