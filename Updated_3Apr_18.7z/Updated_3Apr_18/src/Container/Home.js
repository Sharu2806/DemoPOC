import React, { Component } from 'react';
import axios from 'axios';
import Header from '../Components/Header';
import Sidebar from '../Components/Sidebar';
import HeadingInfo from '../Components/HeadingInfo'
import Details from '../Components/Details'
import '../Style/navbar.css'


class Home extends Component {
  constructor() {
    super();
    this.state = {
      pieChartData : [],
      lineChartData : []
    };
  }
  componentWillMount(){
      this.fetchChargeBackData();
      this.fetchPerformanceCompareData();
  }

  fetchChargeBackData(){
    let that = this;
    axios.get('http://localhost:8080/merchantStatement/chargeback?merchantNumber=5644588')
      .then(function (response) {
          let obj = response.data.chargeBackResponse;
          that.setState((prevState,props)=>{
           return {pieChartData : obj};
        }
      );
      }).catch(function (error) {
        console.log(error);
      });
  }

  fetchPerformanceCompareData(){
    let that = this;
    axios.get('http://localhost:8080/merchantTradeNetSale/comparativenetsales?merchantNumber=5644588')
      .then(function (response) {
          let obj = response.data.merchantCompetitorNetSale;
          that.setState((prevState,props)=>{
           return {lineChartData : obj};
        });
      }).catch(function (error) {
        console.log(error);
      });
  }

  render() {
    return (
      <div>
          <Header />
          <div id="wrapper">
            <Sidebar />
            <div id="main-wrapper" className="col-md-10 pull-right">
              <HeadingInfo />
              <div id="main">
                  <Details dataToPass={this.state.pieChartData} dataForLineChart={this.state.lineChartData}/>
              </div>
            </div>
          </div>
        </div>
    );
  }
}

export default Home;
