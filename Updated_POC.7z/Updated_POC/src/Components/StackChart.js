import React, { Component } from 'react';
import { render } from 'react-dom';
import axios from 'axios';
import '../Style/navbar.css'
import '../style.css';

//google.charts.load('current', {'packages':['corechart']});
class StackChart extends Component {
  constructor() {
    super();
    this.state ={
      chargeBackData  :[['Card Brand', 'ChargeBack']]
    }
    this.drawChart = this.drawChart.bind(this);
  }

  componentWillMount(){
    let that = this;
    axios.get('http://localhost:8080/merchantTradeNetSale/tradenetsale?merchantNumber=5644588')
      .then(function (response) {
          let obj = response.data.chargeBackResponse;
          let data = [...that.state.chargeBackData];
          obj.forEach((i)=>{
            let details =[];
             details[0] = i.cardBrand;
             details[1] = i.tranAmountChg
             data.push(details);
          })
          that.setState({
            chargeBackData : data
          })
      })
      .catch(function (error) {
        console.log(error);
      });

  }

  componentDidMount(){
    window.google.charts.load('current', {'packages':['corechart']});
    window.google.charts.setOnLoadCallback(() => this.drawChart());
  }

  drawChart() {
        /*var data = [];
        for (var i = 0; i < this.state.chargeBackData.length; i++) {
                  data[i] = [this.state.chargeBackData[i][0], this.state.chargeBackData[i][1]];
            }
        var chartData = window.google.visualization.arrayToDataTable(data);*/
        var data = window.google.visualization.arrayToDataTable([
          ['Month', 'Northampton', 'London', 'Manchester' ],
          ['Jan', 10, 24, 20],
          ['Feb', 16, 22, 23],
          ['Mar', 28, 19, 29]
      ]);
        var options = {
          title: 'Your Net Sales : Monthly and Location wise',
          legend: { position: 'top', maxLines: 3 },
          bar: { groupWidth: '40%' },
          isStacked: true,
          colors: ['#144C73', '#2C82BE', '#53A8E2', '#76DDFB'],
          chartArea : {top:30,height:'75%'},
          legend : {position:'top' ,textStyle: {color: '#4A5265', fontSize: 10}},
          height: 300
        };

        var chart = new window.google.visualization.ColumnChart(this.stackChart);
        chart.draw(data, options);
  }
   render() {
    return (
          <div ref={(input) => { this.stackChart = input; }}></div>
    );
    }

}

export default StackChart;
