import React, { Component } from 'react';
import { render } from 'react-dom';
import PieCharts from './PieCharts';
import StackChart from './StackChart';
import LineChart from './LineChart';
import '../Style/navbar.css'
import '../style.css'
import NetSaleInviceDetails from './NetSaleInviceDetails';
import ChargeProccessFees from './ChargeProccessFees';
import MerchantDetails from './MerchantDetails';

let HeadingInfo = (props) =>{
    return (
      <div>
          <div className="row minfo">
              <MerchantDetails  merchantInfo={props.dataToPass}/>
              <div className="col col-md-6 total_box">
                  <NetSaleInviceDetails />
                  <ChargeProccessFees />
              </div>
          </div>

          <div className="row">
              <div className="col col-md-6 stack_details">
                <StackChart />
              </div>
              <div className="col col-md-6 pie_details">
                <PieCharts pieChartDetails={props.dataToPass}/>
              </div>
          </div>

          <div className="row">
              <div className="col col-md-10 line_chart">
                <LineChart lineChartDetails={props.dataForLineChart}/>
              </div>
          </div>

      </div>
    );
  }


export default HeadingInfo;
