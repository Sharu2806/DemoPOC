import React, { Component } from 'react';
import '../Style/navbar.css'


let Header = () =>{
    return (
      <div id="header" className="navbar navbar-default navbar-fixed-top custom_navbar">
        <nav className="collapse navbar-collapse">
          <ul className="nav navbar-brand bank_logo">
            <li>
              <a className="bank_logo">
                <img src="images/logo.png" alt="logo"></img>
              </a>
            </li>
          </ul>
          <ul className="nav navbar-brand">
              <li><a className="brand_text bank_logo"><strong>Merchant Services Portal</strong></a></li>
          </ul>
          <ul className="nav navbar-brand pull-right">
            <li >
              <a className="bank_logo"><span className="brand_text">Welcome, Simon</span><img src="images/avatar.png" alt="avtar"></img></a>
            </li>
          </ul>
        </nav>
      </div>
    );
}


export default Header;
