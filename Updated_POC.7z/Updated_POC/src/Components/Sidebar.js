import React, { Component } from 'react';
import { Link } from 'react-router-dom'

class Sidebar extends Component {
  constructor() {
    super();
    this.state = {
      name: 'React'
    };
  }

  render() {
    return (

      <div id="sidebar-wrapper" className="col-md-2">
                <div id="sidebar">
                    <ul className="nav list-group">
                        <li>
                              <Link className="list-group-item" to='/'>
                                <img src="Images/home.png"></img><span>Insights</span>
                              </Link>
                        </li>
                        <li>
                            <Link className="list-group-item" to='/reports'>

                              <img src="Images/reports.png"></img><span>Reports</span>
                            </Link>
                        </li>
                    </ul>
                </div>
            </div>
    );
  }
}

export default Sidebar;
