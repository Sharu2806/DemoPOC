import React, { Component } from 'react';
import { render } from 'react-dom';
import Reports from './Container/Reports';
import Home from './Container/Home';
import './style.css';
import { BrowserRouter as Router,
  Link,
  Route,
  Switch } from "react-router-dom";



render(
  <Router>
    <Switch>
          <Route exact path="/" component={Home} />
          <Route path="/reports" component={Reports} />
    </Switch>
  </Router>

  , document.getElementById('root')
);
