import React, { Component } from 'react';
import { render } from 'react-dom';
import Header from '../Components/Header';
import Sidebar from '../Components/Sidebar';
import HeadingInfo from '../Components/HeadingInfo'
import Navigation from '../Report_Components/Navigation/Navigation'
import ReportDetails from '../Report_Components/Report/ReportDetails'
import '../Style/navbar.css'


class Reports extends Component {
  constructor() {
    super();
    this.state = {
      name: 'React'
    };
  }
  render() {
    return (
      <div>
          <Header />
          <div id="wrapper">
            <Sidebar />
            <div id="main-wrapper" className="col-md-10 pull-right">
              <HeadingInfo />
              <Navigation />
              <div id="main">
                  <ReportDetails />
              </div>
            </div>
          </div>
        </div>
    );
  }
}

export default Reports;
